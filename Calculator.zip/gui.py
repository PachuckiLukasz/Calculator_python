from tkinter import *

from Calculator import Calculator

root = Tk()
frame = Frame(root)
frame.pack()

entry = Entry(frame, width=20)
entry.pack()

count = Button(frame, text = "Oblicz: ", command = Calculator.perform_operation)

root.mainloop()

def: 