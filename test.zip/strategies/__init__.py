from .add import AddStrategy
from .sub import SubStrategy
from .mul import MulStrategy
from .pow import PowStrategy
from .div import DivStrategy
from .mod import ModStrategy
from .root import RootStrategy
from .log import LogStrategy

